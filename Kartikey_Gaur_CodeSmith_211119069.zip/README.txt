User and Post Management API

Overview:

This project provides a RESTful API for managing users and posts in a simplified social media application. The API allows for the creation and retrieval of users and posts, with secure password handling and basic data operations.

Features:

Create a User: Register a new user with hashed passwords.
Get User Details: Retrieve user details (excluding password).
Create a Post: Add a new post with a caption and image URL.
Get Post Details: Retrieve details of a specific post.
Get Posts by User: Retrieve all posts associated with a specific user.

Technologies:

Go (Golang)
PostgreSQL
Gorilla Mux Router
BCrypt for password hashing
Setup
Prerequisites
Go 1.18 or later
PostgreSQL
github.com/gorilla/mux
github.com/lib/pq

Disclaimer:
The database password has been removed due to safety reasons of the individual.